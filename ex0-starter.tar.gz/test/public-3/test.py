import os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname( __file__ ), '..', '..')))

from ex0 import calc
import pickle

answer = calc(["(",4,"+",5,")","*","(",1,"+",1,")"])
print(answer)
with open('output', 'wb') as f:
  pickle.dump(answer, f)
