
# Exercise 0 -- Write a simple calculator for the language:
#
#  E ::= E + E
#      | E * E
#      | ( E )
#      | nat
#
# Use conventional precedence and associativity. The input is a list of tokens where each token is either a natural number, or a 1-character string "(", ")", "+", or "*"
#
# For example, calc([2, "*", "(", 3, "*", 4, ")"])
#     should return 24
#
# Return the string "error" if the input is not a valid expression.
#  
# For example, calc([1, "+", "("])
#     should return "error"


def calc(toks):
  pass  

  
